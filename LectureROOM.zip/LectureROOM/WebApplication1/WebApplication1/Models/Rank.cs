﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Rank
    {
        public int RankId { get; set; }

        public string RankName { get; set; }

        public ICollection<Student> Students { get; set; }

        public ICollection<Administrator> Administrators { get; set; }

        public ICollection<Teacher> Teachers { get; set; }
    }
}
