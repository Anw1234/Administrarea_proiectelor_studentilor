﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class LectureRoomContext : DbContext
    {
        public LectureRoomContext(DbContextOptions<LectureRoomContext> options)
            : base(options)
        { }
        public DbSet<Rank> Ranks { get; set; }

        public DbSet<Student> Students { get; set; }

        public DbSet<Administrator> Administrators { get; set; }

        public DbSet<Teacher> Teachers { get; set; }

        public DbSet<Year> Years { get; set; }

        public DbSet<Class> Classes { get; set; }

        public DbSet<StudentClass> StudentClasses { get; set; }

        public DbSet<TeacherClass> TeacherClasses { get; set; }

        public DbSet<Assignment> Assignments { get; set; }
    }
}
