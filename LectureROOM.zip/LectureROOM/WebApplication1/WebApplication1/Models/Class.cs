﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Class
    {
        public int ClassId { get; set; }

        public string Name { get; set; }

        public string Comments { get; set; }

        public ICollection<StudentClass> StudentClasses { get; set; }

        public ICollection<TeacherClass> TeacherClasses { get; set; }

        public ICollection<Assignment> Assignments { get; set; }
    }
}
